//main.c===============================================
#include <SDL2/SDL_rect.h>
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

#include <time.h>
#include "mnoise.h"
#include "msine.h"
#include <SDL2/SDL_render.h>
#include <SDL2/SDL_stdinc.h>
#include <SDL2/SDL_surface.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
//flags
#define printfps 0
#define printLog 0
//macros

typedef float  F;
typedef int    I;
typedef Uint32 UI;
typedef void   V;
typedef double D;
#define R return
#define ef else if
typedef struct {I x,y,w,h;} Box;
typedef struct _disp{Box B; SDL_Surface* sf; V (*fnc)(struct _disp* , Uint32* );} disp;
typedef struct {Box B; SDL_Texture* tx; SDL_Texture* txH;SDL_Texture* txP; V (*fnc)(V); I status;} Btn;
//TEXTURES=====================================================================================================================
//TEXTURES=====================================================================================================================
//TEXTURES=====================================================================================================================
enum txIdx {
    TXspace,
    TXbg,
    TXfg,
    TXmeter,
    TXhullmeter,
    TXquestion,
    TXcross,
    TXrocket,
    TXrocketshade,
    TXVol,TXVolpeg,TXVolpegL,
    TXbook0,
    TXprog,
    TX_COUNT
};
enum animId{
    ANship,
    ANshoot,
    ANboom,
    ANwarp,
    ANfire,
    ANsky,
    ANBook,
    AN_COUNT
};
typedef struct {
    char path[128];
    SDL_Texture *tx;
} txture;



int animsCnt[AN_COUNT] = {
    [ANship] = 120,
    [ANshoot] = 16,
    [ANwarp] = 12,
    [ANboom] = 24,
    [ANfire] = 24,
    [ANsky] = 24,
    [ANBook] = 7,
};

txture anims[AN_COUNT] = {
    [ANship] = { "res/anim/ship/", NULL },
    [ANshoot] = { "res/anim/shoot/", NULL },
    [ANboom] = { "res/anim/boom/", NULL },
    [ANwarp] = { "res/anim/warp/", NULL },
    [ANfire] = { "res/anim/fire/", NULL },
    [ANsky] = { "res/anim/sky/", NULL },
    [ANBook] = { "res/anim/book/", NULL },
};

txture *animFrames[AN_COUNT] = {0};

txture txs[TX_COUNT] = {
    [TXspace] = { "res/screen/space180x120.png", NULL },
    [TXbg] = { "res/ld59bg.png", NULL },
    [TXfg] = { "res/ld59fg.png", NULL },
    [TXmeter] = { "res/meter.png", NULL },
    [TXhullmeter] = { "res/hullmeter.png", NULL },
    [TXquestion] = { "res/qestion.png", NULL },
    [TXcross] = { "res/crosshair.png", NULL },
    [TXrocket] = { "res/rocket.png", NULL },
    [TXrocketshade] = { "res/rocketshade.png", NULL },
    [TXVol] = { "res/volume.png", NULL },
    [TXVolpeg] = { "res/volumePeg.png", NULL },
    [TXVolpegL] = { "res/volumePegLift.png", NULL },
    [TXbook0] = { "res/book/ld59book_0000.png", NULL },
    [TXprog] = { "res/progui.png", NULL },
};
//Enums===========================================================================================================================================
//Enums===========================================================================================================================================
//Enums===========================================================================================================================================
typedef enum {
   BLACK =  0xFF000000,
   RED   = 0xFFFF94B2,
   GREEN = 0xFF3ADE19,
   BLUE = 0xFFFFFB2B,
   PINK  = 0xFFB048F9,
} sigCol;

typedef enum {
   Hi, Resupply, Happy, Agree, //positive
   Angry, Hostile, Back_off , Disagre, //negative
   Figth ,Identify,Opinion, Question, //standard
   Nslime,Nbug,Ngrey, Ncyber, //names
   Ignore, //i dun remember why we haz this
   Msg_COUNT
} Msg;
//structs=============================================
typedef struct {
   sigCol in[4]; 
   Msg    m;
} MsgCode;
//declares============================================

MsgCode alienInterpret(sigCol in[4]);
MsgCode *getAlienBook(void);
Msg decodeAlienMsg(sigCol in[4]);

V reset();
I inBox(I x, I y, Box B);
V printStats();
V addFuel();
V rmFuel();
V takeDmg();
I msgKnown(MsgCode *book, Msg m);
V alienLeave();
V newAlien();
V alienAttack();
V playSoundError( );
V quit();
V drwMainDisp(disp* d, Uint32* p);
V drwSignalDisp(disp* d, Uint32* p);
V drawDisp(disp* d, Uint32* p);
V setDrwCol(I c);
V setDrwCol0();
V setDrwCol1();
V setDrwCol2();
V setDrwCol3();
V setDrwCol4();
V generateNoiseSignal();
I sigMod(I i);
V readSignalbuffer();
V tick(F dt);
V events();
V drwBtn(Btn* b);
V render();
V warp();
V fight();
V mainLoop();
V OPTflyAway();
V OPTtrade();
V OPTfight();
V initBTN();
I init();
I main();
//random declares==========================================================================================
//random declares==========================================================================================
//random declares==========================================================================================
#if printfps
static F fpsTimer = 0;
static I fpsFrames = 0;
#endif
#define W 948
#define H 533
#define PS W*H
#define BGNoiseStr .1
I alienX, alienY;
I running;
I hp; I fuel; I fuelMax=10, hpMax=3, ammo, ammoMax=3, prog, progMAX=10;
I won=0;
I lost=0;
I skyTex=0;
F alienCd=3;




I mx; I my; //mouse
#define mkeyn 12 
I MKEYS[mkeyn];

SDL_Window     *wind;
SDL_Renderer   *rend;
SDL_Surface    *surf;
disp* disp1;
disp* disp2;
#define MX_EBTNS 3
Btn* ebtns[MX_EBTNS];
I ebtn;

#define MX_BTNS 7
Btn* btns[MX_BTNS];
I AlresponseDelay=20;
I AlsilentCount;
F RwarpPowNoise=0;
F GwarpPowNoise=0;
F BwarpPowNoise=0;
#define  warpDecay .95;
#define  signalLogW 450
Uint32 signalLog[signalLogW];
F signalPwrLog[signalLogW];
Uint32 signalLogA[signalLogW];
F signalPwrLogA[signalLogW];
Uint32 snoiseLog[signalLogW];
F signalLogPoint=0;
I actTaken[Msg_COUNT];
F mood= 0;
I alienType=2;
//arrays=============================================
//ALIEN=============================================
//ALIEN=============================================
//ALIEN=============================================



typedef enum {
   ALbug,
   ALgrey,
   ALslime,
   ALcyber,
   Alien_COUNT
} AlienType;

MsgCode alienTalkStandard[Msg_COUNT] = {
   [Hi]        = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },
   [Resupply]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },
   [Happy]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },
   [Agree]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },

   [Angry]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },
   [Hostile]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },
   [Back_off]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },
   [Disagre]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },

   [Figth]     = { { RED,   PINK,  RED,   BLUE  }, Figth    },
   [Identify]  = { { BLUE,  GREEN, BLUE,  PINK  }, Identify },
   [Opinion]   = { { GREEN, PINK,  GREEN, BLUE  }, Opinion  },
   [Question]  = { { RED,   BLUE,  GREEN, PINK  }, Question },

   [Nslime]    = { { GREEN, GREEN, GREEN, GREEN }, Nslime   },
   [Nbug]      = { { PINK,  RED,   PINK,  RED   }, Nbug     },
   [Ngrey]     = { { BLUE,  BLUE,  GREEN, GREEN }, Ngrey    },
   [Ncyber]    = { { RED,   GREEN, PINK,  BLUE  }, Ncyber   },

   [Ignore]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore   },
};

// bug
// does not like talking but will trade
// likes repetition
// likes red, blue
// can provide ammo
MsgCode alienTalk1[Msg_COUNT] = {
   [Hi]        = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Resupply]  = { { RED,   PINK,  GREEN, BLUE  }, Resupply  }, // shared colourcode with slime Resupply
   [Happy]     = { { BLUE,  PINK,  BLUE,  RED   }, Happy     }, // shared colourcode with slime Agree
   [Agree]     = { { RED,   GREEN, PINK,  BLUE  }, Agree     }, // shared colourcode with slime Happy

   [Angry]     = { { RED,   BLUE,  RED,   PINK  }, Angry     },
   [Hostile]   = { { PINK,  BLUE,  RED,   BLUE  }, Hostile   }, // shared colourcode with cyber Hi
   [Back_off]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Disagre]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Figth]     = { { BLUE,  RED,   PINK,  RED   }, Figth     },
   [Identify]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Opinion]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Question]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Nslime]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Nbug]      = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ngrey]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ncyber]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Ignore]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
};

// grey
// needs to be intimidated
// hates variety
// hates red
MsgCode alienTalk2[Msg_COUNT] = {
   [Hi]        = { { GREEN, BLUE,  GREEN, GREEN }, Hi        }, // shared colourcode with slime Hi
   [Resupply]  = { { BLUE,  GREEN, GREEN, PINK  }, Resupply  },
   [Happy]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Agree]     = { { BLUE,  GREEN, PINK,  GREEN }, Agree     },

   [Angry]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Hostile]   = { { GREEN, BLUE,  BLUE,  PINK  }, Hostile   },
   [Back_off]  = { { PINK,  GREEN, GREEN, PINK  }, Back_off  }, // shared colourcode with slime Disagre
   [Disagre]   = { { PINK,  BLUE,  GREEN, BLUE  }, Disagre   },

   [Figth]     = { { BLUE,  BLUE,  PINK,  GREEN }, Figth     },
   [Identify]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Opinion]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Question]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Nslime]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Nbug]      = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ngrey]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ncyber]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Ignore]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
};

// slime
// player can sweettalk into exta fuel
// loves green
// has a lot of influnce from other languages and loan words
MsgCode alienTalk3[Msg_COUNT] = {
   [Hi]        = { { GREEN, BLUE,  GREEN, GREEN }, Hi        }, // shared colourcode with grey Hi
   [Resupply]  = { { RED,   PINK,  GREEN, BLUE  }, Resupply  }, // shared colourcode with bug Resupply
   [Happy]     = { { RED,   GREEN, PINK,  BLUE  }, Happy     }, // shared colourcode with bug Agree
   [Agree]     = { { BLUE,  PINK,  BLUE,  RED   }, Agree     }, // shared colourcode with bug Happy

   [Angry]     = { { PINK,  BLUE,  RED,   GREEN }, Angry     },
   [Hostile]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Back_off]  = { { BLUE,  PINK,  GREEN, RED   }, Back_off  }, // shared colourcode with cyber Disagre
   [Disagre]   = { { PINK,  GREEN, GREEN, PINK  }, Disagre   }, // shared colourcode with grey Back_off

   [Figth]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Identify]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Opinion]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Question]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Nslime]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Nbug]      = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ngrey]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ncyber]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Ignore]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
};

// cyber
// player must politely ask to keep their distance or get shot
// likes red, purple
// likes elaborate patterns
MsgCode alienTalk4[Msg_COUNT] = {
   [Hi]        = { { PINK,  BLUE,  RED,   BLUE  }, Hi        }, // shared colourcode with bug Hostile
   [Resupply]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Happy]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Agree]     = { { BLUE,  PINK,  BLUE,  RED   }, Agree     }, // shared colourcode with slime Agree

   [Angry]     = { { BLUE,  RED,   PINK,  RED   }, Angry     },
   [Hostile]   = { { BLUE,  RED,   BLUE,  GREEN }, Hostile   },
   [Back_off]  = { { PINK,  GREEN, GREEN, PINK  }, Back_off  }, // shared colourcode with grey/slime
   [Disagre]   = { { BLUE,  PINK,  GREEN, RED   }, Disagre   }, // shared colourcode with slime Back_off

   [Figth]     = { { RED,   PINK,  RED,   BLUE  }, Figth     }, // same as standard Figth
   [Identify]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Opinion]   = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Question]  = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Nslime]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Nbug]      = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ngrey]     = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
   [Ncyber]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },

   [Ignore]    = { { BLACK, BLACK, BLACK, BLACK }, Ignore    },
};

F playShootMax=1.6;
F playShoot=-1;
F boomEffect=-1;
F warpEffectMax=.9;
F warpEffect=-1;
F fireEffectMax=2;
F fireEffect=-1;

typedef struct {
   // -1 to 1, negative means they need to be under that positive value, ie intimidation
   F rerefuel; // + 1 fuel
   F rearm;    // + 1 ammo
   F fireFlee; // will fire at you if you run away
} alienTreshold;

alienTreshold alienTresholds[Alien_COUNT] = {
   [ALbug]   = { .rerefuel =  0.2f, .rearm =  0.2f, .fireFlee = -0.4f },
   [ALgrey]  = { .rerefuel = -0.4f, .rearm = -0.4f, .fireFlee =  0.5f },
   [ALslime] = { .rerefuel =  0.7f, .rearm =  0.8f, .fireFlee = -0.3f },
   [ALcyber] = { .rerefuel = -0.2f, .rearm =  0.5f, .fireFlee = -0.8f },
};

Msg alienName(){
   if(alienType==ALbug  ){ return Nbug;   }
   if(alienType==ALgrey ){ return Ngrey;  }
   if(alienType==ALslime){ return Nslime; }
   return Ncyber;
}

MsgCode alienOpinionCode(F op){
   if(op <= .15f) return (MsgCode){ { RED,   RED,   RED,   RED   }, Opinion };
   if(op <= .35f) return (MsgCode){ { GREEN, RED,   RED,   RED   }, Opinion };
   if(op <= .65f) return (MsgCode){ { GREEN, GREEN, RED,   RED   }, Opinion };
   if(op <= .85f) return (MsgCode){ { GREEN, GREEN, GREEN, RED   }, Opinion };
   return              (MsgCode){ { GREEN, GREEN, GREEN, GREEN }, Opinion };
}

MsgCode alienInterpret(sigCol in[4]){
   Msg m = decodeAlienMsg(in);
   MsgCode *book = getAlienBook();

   if(!msgKnown(book, m) && !msgKnown(alienTalkStandard, m)){
      return alienTalkStandard[Question];
   }

   I taken = actTaken[m];
   actTaken[m] = 1;
   #define one if(!taken)
   #define two if(taken)
   #define moodPass(v) ((v) < 0 ? (mood <= -(v)) : (mood >= (v)))
   #define say(mm) (msgKnown(book, (mm)) ? book[(mm)] : alienTalkStandard[(mm)])
   #define makeFleeSafe() do { \
      if(t->fireFlee < 0){ \
         F lim = -(t->fireFlee); \
         if(mood <= lim) mood = lim + .01f; \
      } else { \
         F lim = t->fireFlee; \
         if(mood >= lim) mood = lim - .01f; \
      } \
   } while(0)

   alienTreshold *t = &alienTresholds[alienType];
   I canSupply = moodPass(t->rerefuel) || moodPass(t->rearm);
   I cowed     = moodPass(t->rerefuel);

   // bug
   // does not like talking but will trade
   // likes repetition
   // likes red, blue
   if(alienType==ALbug){
      if(m==Question    ) { mood -= .08f; return alienTalkStandard[Question]; }
      if(m==Identify    ) { mood -= .22f; return alienTalkStandard[alienName()]; }
      if(m==Opinion     ) { mood -= .10f; return alienOpinionCode(mood); }

      if(m==Nbug        ) { one{mood += .15f;} return say(Agree); }
      if(m==Nslime      ) {      mood -= .25f;  return say(Angry); }
      if(m==Ngrey       ) {      mood -= .10f;  return alienTalkStandard[Question]; }
      if(m==Ncyber      ) {      mood -= .05f;  return alienTalkStandard[Question]; }

      if(m==Resupply    ) { one{} two{mood += .10f;}     return canSupply ? say(Agree)    : say(Angry); }
      if(m==Agree       ) { one{return say(Agree);}      two{return canSupply ? say(Resupply) : say(Agree);} }
      if(m==Angry       ) { one{mood += .05f;}           return say(Agree); }
      if(m==Happy       ) {                              mood -= .08f; return say(Angry); }
      if(m==Back_off    ) { one{makeFleeSafe();}         return say(Agree); }
      if(m==Figth       ) { if(mood<.2f){alienAttack();} return say(Angry); }
      if(m==Hostile     ) { if(mood<.1f){alienAttack();} return say(Angry); }
      mood -= .03f;
   }

   // grey
   // needs to be intimidated
   // hates variety
   // hates red
   if(alienType==ALgrey){
      if(m==Question    ) {                             return alienTalkStandard[Question]; }
      if(m==Identify    ) { mood -= .18f;              return alienTalkStandard[alienName()]; }
      if(m==Opinion     ) { mood -= .12f;              return alienOpinionCode(mood); }

      if(m==Ngrey       ) { one{mood -= .20f;}         return cowed ? say(Agree)    : say(Disagre); }
      if(m==Nbug        ) {                            return alienTalkStandard[Question]; }
      if(m==Nslime      ) {                            return alienTalkStandard[Question]; }
      if(m==Ncyber      ) {                            return alienTalkStandard[Question]; }

      if(m==Hi          ) { one{mood += .10f;}         return say(Back_off); }
      if(m==Agree       ) { one{mood += .05f;}         return say(Back_off); }
      if(m==Disagre     ) { one{}                      return cowed ? say(Agree)    : say(Back_off); }
      if(m==Back_off    ) { one{makeFleeSafe();}       return say(Back_off); }

      if(m==Hostile     ) { one{mood -= .30f;}         return cowed ? say(Agree)    : say(Disagre); }
      if(m==Figth       ) { one{mood -= .50f;}         return cowed ? say(Resupply) : say(Disagre); }
      if(m==Resupply    ) { one{}                      return canSupply ? say(Agree) : say(Back_off); }
   }

   // slime
   // player can sweettalk into exta fuel
   // loves green
   // has a lot of influnce from other languages and loan words
   if(alienType==ALslime){
      if(m==Question    ) { one{mood += .05f;}         return alienTalkStandard[Question]; }
      if(m==Identify    ) { mood -= .10f;              return alienTalkStandard[alienName()]; }
      if(m==Opinion     ) { mood -= .03f;              return alienOpinionCode(mood); }

      if(m==Nslime      ) { one{mood += .30f;}         return say(Happy); }
      if(m==Nbug        ) { one{mood -= .40f;}         return say(Angry); }
      if(m==Ngrey       ) { one{}                      return alienTalkStandard[Question]; }
      if(m==Ncyber      ) { one{}                      return alienTalkStandard[Question]; }

      if(m==Hi          ) { one{mood += .20f;}         return say(Hi); }
      if(m==Happy       ) { one{mood += .20f;}         return mood>.7f ? say(Happy) : say(Disagre); }
      if(m==Agree       ) { one{mood += .20f;}         return say(Happy); }
      if(m==Resupply    ) { one{mood += .10f;}         return canSupply ? say(Agree) : say(Disagre); }

      if(m==Angry       ) { one{mood -= .20f;}         return mood<.4f ? say(Angry) : say(Disagre); }
      if(m==Disagre     ) { one{mood -= .20f;}         return say(Angry); }
      if(m==Back_off    ) { one{makeFleeSafe();} two{alienAttack();} return say(Back_off); }
      if(m==Figth       ) { one{mood -= .25f;}         return say(Angry); }
   }

   // cyber
   // player must politely ask to keep their distance or get shot
   // likes red, purple
   // likes elaborate patterns
   if(alienType==ALcyber){
      if(m==Question    ) { mood -= .03f;              return alienTalkStandard[Question]; }
      if(m==Identify    ) { mood -= .20f;              return alienTalkStandard[alienName()]; }
      if(m==Opinion     ) { mood -= .07f;              return alienOpinionCode(mood); }

      if(m==Ncyber      ) {                            return alienTalkStandard[Question]; }
      if(m==Nbug        ) {                            return alienTalkStandard[Question]; }
      if(m==Ngrey       ) {                            return alienTalkStandard[Question]; }
      if(m==Nslime      ) {                            return alienTalkStandard[Question]; }

      if(m==Hi          ) { one{mood += .10f;}         return say(Back_off); }
      if(m==Agree       ) {                            return say(Back_off); }
      if(m==Disagre     ) {                            return say(Back_off); }
      if(m==Resupply    ) {                            return say(Back_off); }

      if(m==Back_off    ) { one{mood += 1.f; makeFleeSafe();} return say(Agree); }
      if(m==Angry       ) {                            return say(Angry); }
      if(m==Figth       ) { alienAttack();             return say(Agree); }
      if(m==Hostile     ) { alienAttack();             return say(Agree); }
   }

   return say(m);
}

//NEILA=============================================
//NEILA=============================================
//NEILA=============================================
//NEILA=============================================



//declares============================================
//
I BookIdx=1;
F warpDelay=0;
F warpPreDelay=0;
F actCd=0;
F t = 0;
I alienShow=0; 
I alienRefueled=0;
V reset(){
   won=0;
   lost=0;
   hp=hpMax;
   prog=0;
   alienShow=0;
   alienRefueled=0;
   for(I i = 0; i < signalLogW; i++){ snoiseLog[i]=0xFF000000; signalLog[i]=0xFF000000; signalLogA[i]=0xFF000000; signalPwrLogA[i]=0;signalPwrLog[i]=0;}
   for(I i = 0; i < signalLogW; i++){ t++; generateNoiseSignal(); }
   ammo=ammoMax;
   fuel=fuelMax*.5;
   alienCd=3;
   warpDelay = -1;
   warpPreDelay = -100;
   actCd = -1;
   playShoot = -11;
   boomEffect = -1;
   warpEffect = -1;
   fireEffect = -1;
}

//helpers
I inBox(I x, I y, Box B){
   if(x<B.x || y< B.y){return 0;}
   if(x-B.w > B.x || y-B.h> B.y){return 0;}

   return 1;
}





V printStats(){
   if(!printLog){return;}
   printf("fuel: %d\n", fuel);
   printf("hp:   %d\n", hp);
   printf("Mood: %.2f\n", mood);
   printf("alien: %d\n",  alienType);
}
V addFuel(){
   fuel++;
   if(fuel>fuelMax){fuel=fuelMax;}
}
V rmFuel(){
   fuel--;
   if(fuel<=0){fuel=0; lost=1; ebtn=1; }
}
V takeDmg(){
   hp-=1;
   if(hp<=0){hp=0;; lost=1; ebtn=2;}
}
MsgCode *getAlienBook(void){
   if(alienType==0){ return alienTalk1; }
   if(alienType==1){ return alienTalk2; }
   if(alienType==2){ return alienTalk3; }
   return alienTalk4;
}
I msgKnown(MsgCode *book, Msg m){
   MsgCode c = book[m];
   return !(c.in[0]==BLACK && c.in[1]==BLACK && c.in[2]==BLACK && c.in[3]==BLACK);
}

Msg decodeAlienMsg(sigCol in[4]){
   MsgCode *book = getAlienBook();
   I i;
   for(i=0; i<Msg_COUNT; i++){ if(book[i].in[0]==in[0] && book[i].in[1]==in[1] && book[i].in[2]==in[2] && book[i].in[3]==in[3]){ return (Msg)i;
      }
   }

   for(i=0; i<Msg_COUNT; i++){
      if(alienTalkStandard[i].in[0]==in[0] && alienTalkStandard[i].in[1]==in[1] && alienTalkStandard[i].in[2]==in[2] && alienTalkStandard[i].in[3]==in[3]){ return (Msg)i;
      }
   }

   return Question;
}
V alienLeave(){
   F warpPowNoise=1.5;
   alienShow=0;
}
V newAlien(){
   alienType=rand()%4;
   RwarpPowNoise=((rand()%10)*.1+.7);
   GwarpPowNoise=((rand()%10)*.1+.7);
   BwarpPowNoise=((rand()%10)*.1+.7);
   mood=rand()%50*.01+.25;
   for(I i= 0; i <Msg_COUNT;i++){ actTaken[i]=0; }
   alienShow=1;
   alienX=(rand()%140+20)*2;
   alienY=(rand()%60+30)*2;

}
V alienAttack(){
   playShoot=playShootMax;
   printf("pewpew");
   alienLeave();
   takeDmg();
}
V playSoundError( ){}






V quit(){ printf("quiting...\n");sinePlayerQuit(); running=0;SDL_Quit(); printf("quit\n"); }
//initializers===============================================================
disp* newDisp(Box b, V (* f)(disp* , Uint32* )){
   disp *d= malloc(sizeof(disp));
   d->B=b;
   d->fnc=NULL;
   if(f!=NULL){ d->fnc=f; }
   d->sf= SDL_CreateRGBSurface(0, b.w , b.h, 32, 0, 0, 0, 0);
   return d;
}
Btn* newBtn(Box B, char* pth, char* pthHov, char* pthPress, V (* f)){
   Btn *b = malloc(sizeof(Btn));
   b->B=B;
   b->tx=IMG_LoadTexture(rend, pth);
   b->txH=IMG_LoadTexture(rend, pthHov);
   b->txP=IMG_LoadTexture(rend, pthPress);
   if(f!=NULL){ b->fnc=f; }
   b->status=0;
   return b;
}
typedef  enum {
   MT_MIX,
   MT_ADD,
} mixType;

UI mixCol(UI c1, UI c2, F pow, mixType t){
   if(pow < 0) pow = 0;
   if(pow > 1) pow = 1;

   #define CH(c, s) (((c) >> (s)) & 0xFFu)
   #define CL(x) ((x) > 0xFFu ? 0xFFu : (x))

   UI a = t == MT_MIX ? (UI)(CH(c2,24) + (CH(c1,24) - CH(c2,24)) * pow) : CL(CH(c2,24) + (UI)(CH(c1,24) * pow));
   UI r = t == MT_MIX ? (UI)(CH(c2,16) + (CH(c1,16) - CH(c2,16)) * pow) : CL(CH(c2,16) + (UI)(CH(c1,16) * pow));
   UI g = t == MT_MIX ? (UI)(CH(c2, 8) + (CH(c1, 8) - CH(c2, 8)) * pow) : CL(CH(c2, 8) + (UI)(CH(c1, 8) * pow));
   UI b = t == MT_MIX ? (UI)(CH(c2, 0) + (CH(c1, 0) - CH(c2, 0)) * pow) : CL(CH(c2, 0) + (UI)(CH(c1, 0) * pow));

   #undef CH
   #undef CL
   return (a << 24) | (r << 16) | (g << 8) | b;
}
//draw funcs===============================================

V drwMainDisp(disp* d, Uint32* p){
   SDL_Rect dst= {(*d).B.x,(*d).B.y,(*d).B.w,(*d).B.h};
   SDL_RenderCopy(rend, animFrames[ANsky][skyTex%24].tx, NULL, &dst);
}
#define  h d->B.h
#define  w d->B.w
#define  xo d->B.x
#define  yo d->B.y
#define SigDispCol mixCol(  mixCol(mixCol(signalLog[pnt], 0xFF000000, signalPwrLog[pnt], MT_MIX),mixCol(signalLogA[pnt], 0xFF000000, signalPwrLogA[pnt], MT_MIX),1,MT_ADD) , snoiseLog[pnt], 1,MT_ADD) 
V drwSignalDisp(disp* d, Uint32* p){
   for(I y= 0; y< h; y++) {
      for(I x= 0; x< w; x++) {

         I idx = (x+xo)+(y+yo)*W;
         if(idx>=PS || idx < 0){continue;}
         I noise=rand()%2 + (I)(2.0*rnd((F)(y+t*126)*.1)-1);
         I pnt=((x+noise+(I)signalLogPoint)%signalLogW);
         p[idx]= SigDispCol;
         if(x==w-5){ sinePlayerFreq(SigDispCol);}
      }
   }
}
V drawDisp(disp* d, Uint32* p){
   if(d->fnc!=NULL){
      d->fnc(d,p);
   }else{
      for(I y= 0; y< h; y++) {
         for(I x= 0; x< w; x++) {
            I idx = (x+xo)+(y+yo)*W;
            if(idx>=PS || idx < 0){continue;}
            p[idx]=0xFF111111;
         }
      }
   }
}
   #undef w
   #undef h
I drwCol;
V setDrwCol(I c){ drwCol=c; }
V setDrwCol0(){ drwCol=BLACK; }
V setDrwCol1(){ drwCol=RED; }
V setDrwCol2(){ drwCol=GREEN; }
V setDrwCol3(){ drwCol=BLUE; }
V setDrwCol4(){ drwCol=PINK; }
//=============================================================================
F acc=0;

#define sigIdx ((I)signalLogPoint-1)% signalLogW
#define sigPrevIdx ((I)signalLogPoint-2)% signalLogW
V generateNoiseSignal(){
      signalLogPoint+=1;
      snoiseLog[((I)signalLogPoint-1)% signalLogW]=0xFF000000;
      I r =(I)(Perlin1D(t*2.5+13277)*0xFF)&0xFF;
      I g =(I)(Perlin1D(t*2+37731)*0xFF)&0xFF;
      I b =(I)(Perlin1D(t*2.3+12567)*0xFF)&0xFF;
      I noise = 0xFF000000 | (r << 16) | (g << 8) | b;
      F noiseStr=Perlin1D(t*115)*BGNoiseStr;
      snoiseLog[((I)signalLogPoint-1)% signalLogW]= mixCol(noise, 0xFF000000, noiseStr, MT_MIX);
      snoiseLog[((I)signalLogPoint-1)% signalLogW]= mixCol( 0xFFFF0000, snoiseLog[((I)signalLogPoint-1)% signalLogW], RwarpPowNoise, MT_ADD);
      snoiseLog[((I)signalLogPoint-1)% signalLogW]= mixCol( 0xFF00FF00, snoiseLog[((I)signalLogPoint-1)% signalLogW], GwarpPowNoise, MT_ADD);
      snoiseLog[((I)signalLogPoint-1)% signalLogW]= mixCol( 0xFF0000FF, snoiseLog[((I)signalLogPoint-1)% signalLogW], BwarpPowNoise, MT_ADD);
}

sigCol   resp[4];
I        respCnt=4;
I        respSpeed=0;
I        respGap=0;
F        respProg=0;
I sigMod(I i){
   i %= signalLogW;
   if(i < 0){ i += signalLogW; }
   return i;
}
V readSignalbuffer(){
   I last=0;
   I cnt=0;
    sigCol msg[4];
   for(I i = 0; i < signalLogW ; i++){
      if(cnt>=4){break;}
      I c = signalLog[sigMod(sigIdx - i)];
      if(c!=last){ 
         if(c==RED){   msg[3-cnt]=c; cnt++; }
         if(c==GREEN){ msg[3-cnt]=c;cnt++; }
         if(c==BLUE){  msg[3-cnt]=c; cnt++;}
         if(c==PINK){  msg[3-cnt]=c; cnt++;}
         last=c;
      }
   }
   MsgCode m = alienInterpret(msg);
   for(I i = 0; i < cnt ; i++){
      I c = msg[i];
      if(c==RED){    printf("R\n"); }
      if(c==GREEN){  printf("G\n"); }
      if(c==BLUE){   printf("B\n"); }
      if(c==PINK){   printf("P\n"); }
   }

   for (I i = 0; i < 4; i++) {
      resp[i] = m.in[i];
   }
   printStats();
   respCnt=0;
   respSpeed=5;
   respGap=3;
   respProg=0;
   for(I i = 0; i < cnt ; i++){
      I c = resp[i];
      if(c==RED){    printf("R\n"); }
      if(c==GREEN){  printf("G\n"); }
      if(c==BLUE){   printf("B\n"); }
      if(c==PINK){   printf("P\n"); }
   }
   
}
I new = 0;
I newReady=0;
F pressPwr=0;
I last;
V wintune(F dt){
      static F wonMusTiem = 0;

      enum {
         NOTE_NONE = 0x00000000,

         NOTE_C3 = 0xFFFF0000,
         NOTE_C4 = 0xFF00FF00,
         NOTE_C5 = 0xFF0000FF,

         OCTAVE_C3_C4 = 0xFFFFFF00,
         OCTAVE_C3_C5 = 0xFFFF00FF,
         OCTAVE_C4_C5 = 0xFF00FFFF,
         OCTAVE_C3_C4_C5 = 0xFFFFFFFF,

         OCTAVE_C3_C4_SOFT = 0xFF404000,
         OCTAVE_C3_C5_SOFT = 0xFF400040,
         OCTAVE_C4_C5_SOFT = 0xFF004040,

         STACK_C3_HEAVY = 0xFFC04040,
         STACK_C4_HEAVY = 0xFF40C040,
         STACK_C5_HEAVY = 0xFF4040C0,

         STACK_BALANCED_LOW = 0xFF804020,
         STACK_BALANCED_MID = 0xFF408040,
         STACK_BALANCED_HIGH = 0xFF204080,
      };


      static const uint32_t music[] = {
   NOTE_C4, NOTE_C5, NOTE_C4, NOTE_NONE,
   NOTE_C3, NOTE_C4, OCTAVE_C4_C5, NOTE_NONE,

   NOTE_C4, NOTE_C5, NOTE_C4, NOTE_NONE,
   NOTE_C3, OCTAVE_C3_C4, NOTE_C5, NOTE_NONE,

   NOTE_C5, OCTAVE_C4_C5, NOTE_C5, NOTE_NONE,
   NOTE_C4, NOTE_C3, OCTAVE_C3_C5, NOTE_NONE,

   NOTE_C4, NOTE_C5, OCTAVE_C3_C4, NOTE_C4,
   OCTAVE_C3_C5, NOTE_NONE, OCTAVE_C3_C4_C5, NOTE_NONE,
};
      wonMusTiem += dt * 4;
      if(wonMusTiem >= (F)(sizeof(music) / sizeof(music[0]))) wonMusTiem = 0;

      static const F noteLen = 0.85f;
      int i = (int)wonMusTiem;
      F stepFrac = wonMusTiem - (F)i;

      snoiseLog[sigIdx] = (stepFrac < noteLen) ? music[i] : 0;

}


#define CANACT (warpPreDelay<0 && !won && !lost && actCd<0)
V tick(F dt){
   if (playShoot>0&&playShoot<.3){boomEffect=1.9; }
   playShoot-=dt;if (playShoot<0&&playShoot>-10){playShoot=-11;}
   boomEffect-=dt;
   warpEffect-=dt;
   if (fireEffect>0 && fireEffect<.9&&alienShow){ fight();}
   fireEffect-=dt;

   warpDelay-=dt; if (warpDelay<0){ warpDelay=-1;}
   actCd-=dt; if (actCd<0){ actCd=-1;}

   warpPreDelay-=dt; if (warpPreDelay<0 && warpPreDelay> -99){ warp(); warpPreDelay=-100;}

   if(won){wintune(dt);}
   if(won || lost ){
      if(MKEYS[1]){
         if(inBox(mx, my, (*ebtns[ebtn]).B)){ebtns[ebtn]->fnc();}
      }
   }
   if(alienCd>=0){alienCd-=dt;if(alienCd<=0.01){alienCd=-1 ; newAlien();}}
   acc+=dt*30;
   I btnDwn=0;
   t+=dt;
   if(!alienShow){new=0;}
   if(MKEYS[1] && CANACT){
      for(I i = 0; i < MX_BTNS; i++){
           if(inBox(mx, my, (*btns[i]).B)){btns[i]->fnc();btnDwn=1;}
      }
   }
   if(MKEYS[1]==2 && CANACT){
         SDL_Rect bookdst = {-30, 170, 300, 300};
      if(my>170 && my<170+300&&!btnDwn){
         if (mx>0 && mx<150-30){if(BookIdx>0) BookIdx-=1;}
         if (mx>150-30 && mx<300-30){ if(BookIdx<6) BookIdx+=1;}
      }
   }
   if(MKEYS[1] && CANACT){
      if(newReady){ signalLog[sigPrevIdx] = 0;}
      if(inBox(mx, my, (*btns[1]).B)){btns[1]->fnc(); pressPwr+=dt*16;if(last!=1 || newReady){ new+=1;newReady=0;last=1;} }
      ef(inBox(mx, my, (*btns[2]).B)){btns[2]->fnc(); pressPwr+=dt*16;if(last!=2 || newReady){ new+=1;newReady=0;last=2;} }
      ef(inBox(mx, my, (*btns[3]).B)){btns[3]->fnc(); pressPwr+=dt*16;if(last!=3 || newReady){ new+=1;newReady=0;last=3;} }
      ef(inBox(mx, my, (*btns[4]).B)){btns[4]->fnc(); pressPwr+=dt*16;if(last!=4 || newReady){ new+=1;newReady=0;last=4;} }
      if(pressPwr>1){pressPwr=1;}
   }else{ pressPwr-=dt*7; if(pressPwr<.1){pressPwr=0;newReady=1;} }
   while(acc > 0){
      RwarpPowNoise*=warpDecay;
      GwarpPowNoise*=warpDecay;
      BwarpPowNoise*=warpDecay;
      generateNoiseSignal();
      signalLog[sigIdx]=0;
      signalLogA[sigIdx]=0;

      if(pressPwr>.01){signalLog[sigIdx]=drwCol; signalPwrLog[sigIdx]=pressPwr;}
      if(respCnt<4) { 
         if(respProg<respSpeed){signalLogA[sigIdx]=resp[respCnt]; signalPwrLogA[sigIdx]=1;}
         respProg+=1;
         if(respProg>respSpeed+respGap){respCnt+=1; respProg=0;}

      }
      if(signalLog[sigIdx]==0){AlsilentCount++;}else{AlsilentCount=0;}

      if(AlsilentCount>AlresponseDelay&& new>=4){ new=0; readSignalbuffer();AlsilentCount=0;}
      ef(AlsilentCount>AlresponseDelay*3){ new=0; AlsilentCount=0;}
      acc-=1;
   }

   if(!MKEYS[1]){ newReady=1; }
   /*VOLUME*///weee hardcode af volume bar!
   /*VOLUME*/if(MKEYS[1] && mx>210 && mx < (220+375+15) && abs(my-(280))<15 ){ sinePlayerVolume(((F)mx-220.0)/375.0); } 
}
V events(){
   SDL_Event e;
   SDL_GetMouseState(&mx, &my);
   for(int i = 0; i < mkeyn; i++){if(MKEYS[i]>1){MKEYS[i]--;}}
   while(SDL_PollEvent(&e)){
      if (e.type == SDL_QUIT){ quit(); }
      ef (e.type == SDL_MOUSEBUTTONDOWN){ if(e.button.button>= mkeyn){continue;} ;MKEYS[e.button.button]=2;}
      ef (e.type == SDL_MOUSEBUTTONUP){   if(e.button.button>= mkeyn){continue;} ;MKEYS[e.button.button]=0;}
   }
}


V drwBtn(Btn* b){
   SDL_Rect dst = {b->B.x, b->B.y, b->B.w, b->B.h};
   if(inBox(mx, my, (*b).B)){ 
      if(MKEYS[1]){ SDL_RenderCopy(rend, b->txP, NULL, &dst);
      }else{ SDL_RenderCopy(rend, b->txH, NULL, &dst); }
   }else{ SDL_RenderCopy(rend, b->tx, NULL, &dst); }
}
V render(){

   sinePlayerTick();
   if (SDL_MUSTLOCK(surf)) SDL_LockSurface(surf);
   Uint32 * p = surf->pixels;

   for(I y= 0; y< H; y++) {
      for(I x= 0; x< W; x++) {
         p[x+y*W]=0x00000000;
      }
   }

   drawDisp(disp2, p);
   if (SDL_MUSTLOCK(surf)) SDL_UnlockSurface(surf);

   SDL_Texture *ScTx = SDL_CreateTextureFromSurface(rend, surf);//draw this on top alpha cut

   SDL_RenderClear(rend);
   //background
   SDL_Rect dst = {0, 0, W, H};
   SDL_RenderCopy(rend, txs[TXbg].tx, NULL, &dst);
   SDL_RenderCopy(rend, ScTx, NULL, NULL);
   drawDisp(disp1, p);


   /*AMMO*/
   I ammoX=695;
   I ammoY=210;
   I ammoD=110;
   for(I i = 0; i < ammo;i++){
      SDL_Rect rckdst= {ammoX,ammoY-ammoD*i,300,250};
   SDL_RenderCopy(rend, txs[TXrocketshade].tx, NULL, &rckdst);
   }
   for(I i = 0; i < ammo;i++){
      SDL_Rect rckdst= {ammoX,ammoY-ammoD*i,300,250};
      SDL_RenderCopy(rend, txs[TXrocket].tx, NULL, &rckdst);
   }
   /*AMMO*/
   for(I i = 0; i < MX_BTNS; i++){
      drwBtn(btns[i]);
   }
  if(won||lost){ drwBtn(ebtns[ebtn]); }
   SDL_Rect bookdst = {-30, 170, 300, 300};
  
   /*SCREEN REGION*/ SDL_Rect clip = {245, 30, 360, 240};
   #define STARTCLIP SDL_RenderSetClipRect(rend, &clip);
   #define ENDCLIP   SDL_RenderSetClipRect(rend, NULL);

   /*meter   */ float PER=1-((F)fuel/(F)fuelMax);
   /*meter   */ I meterH=190;
   /*meter   */ SDL_Rect meterdst= {600, 50+meterH*PER, 100, 190-meterH*PER};
   /*meter   */ SDL_Rect metersrc= {0, 0+meterH*PER, 100, 190-meterH*PER};
   /*meter   */ SDL_RenderCopy(rend, txs[TXmeter].tx, &metersrc, &meterdst);
STARTCLIP

      SDL_Rect shipDst= {245 + alienX - 90, 30 + alienY - 60, 180,120 };

if(playShoot>0){
      SDL_RenderCopy(rend, animFrames[ANshoot][(I)((playShootMax-playShoot)*12)%16].tx , NULL, &shipDst);
   } ef(alienShow ){
      SDL_RenderCopy(rend, animFrames[ANship][(I)(t*6)%120].tx , NULL, &shipDst);
   }
   /*CROSSHAIR*/; if(alienShow && 0){
  /*CROSSHAIR*/ SDL_Rect crossdst = {245 + alienX - 352, 30 + alienY - 59, 421, 283};
  /*CROSSHAIR*/ 
  /*CROSSHAIR*/ SDL_RenderCopy(rend, txs[TXcross].tx, NULL, &crossdst); 
   /*CROSSHAIR*/} 
   
  /*PROGRESS*/ SDL_Rect prgdst = {150-(360-100)*(1-((F)prog)/((F)progMAX)), 18, 450, 75};
  /*PROGRESS*/ SDL_RenderCopy(rend, txs[TXprog].tx, NULL, &prgdst); 
   
  /*CROSSHAIR*/ 
   


   /*SCREEN REGION*/ SDL_Rect fireclip = {245+alienX-180, 30+alienY-120, 360, 240};
if(fireEffect>0){
      SDL_RenderCopy(rend, animFrames[ANfire][(I)((fireEffectMax-fireEffect)*12)%24].tx , NULL, &fireclip);
   }
if(boomEffect>0){
      SDL_RenderCopy(rend, animFrames[ANboom][(I)((2.0-boomEffect)*12)%24].tx , NULL, &clip);
   }
if(warpEffect>0){
      SDL_RenderCopy(rend, animFrames[ANwarp][(I)((warpEffectMax-warpEffect)*12)%12].tx , NULL, &clip);
   }
ENDCLIP
   SDL_RenderCopy(rend, txs[TXfg].tx, NULL, &dst);//FG=====================================
   /*VOLUME*/ SDL_Rect voldst= {200, 250, 450, 50};  SDL_RenderCopy(rend, txs[TXVol].tx, NULL, &voldst);
   /*VOLUME*/ I PEGDST=6;
   /*VOLUME*/ for(I i = 0; i < (375.0/PEGDST)*usrVOLUME;i++){ SDL_Rect volPdst= {220+i*PEGDST, 275, 11, 15}; 
      if(abs(mx-(220+i*PEGDST))<15&&abs(my-(280))<15){SDL_RenderCopy(rend, txs[TXVolpegL].tx, NULL, &volPdst);}else{ SDL_RenderCopy(rend, txs[TXVolpeg].tx, NULL, &volPdst); }}

  /*Question */ SDL_Rect quedst = {430, 220, 200, 50};
  /*Question */ if(alienShow){SDL_RenderCopy(rend, txs[TXquestion].tx, NULL, &quedst);}
   //hull meter
   float hPER=((F)hp/(F)hpMax);
   I hullmeterw=135;
   SDL_Rect hmeterdst= {248, 230, hullmeterw*hPER, 40};
   SDL_Rect hmetersrc= {0,   0, hullmeterw*hPER, 40};
   SDL_RenderCopy(rend, txs[TXhullmeter].tx, &hmetersrc, &hmeterdst);
   //


   SDL_RenderCopy(rend, animFrames[ANBook][(I)(BookIdx)%7].tx , NULL, &bookdst);
   drwBtn(btns[1]);
//   //****************TODO DELETE SHITTY SCREENSHOT CODE******************************''
//   //****************TODO DELETE SHITTY SCREENSHOT CODE******************************''
//   //****************TODO DELETE SHITTY SCREENSHOT CODE******************************''
//   if(MKEYS[2]){
//      time_t t = time(NULL);
//      struct tm *tmv = localtime(&t);
//      if(!tmv){ printf("localtime fail\n"); return; }
//
//      char path[64];
//      strftime(path, sizeof(path), "shot_%H%M%S.png", tmv);
//
//      SDL_Surface *shot = SDL_CreateRGBSurfaceWithFormat(0, W, H, 32, SDL_PIXELFORMAT_ARGB8888);
//      if(!shot){ printf("screenshot surface fail: %s\n", SDL_GetError()); return; }
//
//      if(SDL_RenderReadPixels(rend, NULL, SDL_PIXELFORMAT_ARGB8888, shot->pixels, shot->pitch) != 0){
//         printf("SDL_RenderReadPixels fail: %s\n", SDL_GetError());
//         SDL_FreeSurface(shot);
//         return;
//      }
//
//      if(IMG_SavePNG(shot, path) != 0){
//         printf("IMG_SavePNG fail: %s\n", IMG_GetError());
//      }else{
//         printf("saved %s\n", path);
//      }
//
//      SDL_FreeSurface(shot);
//   }
//   //****************TODO DELETE SHITTY SCREENSHOT CODE******************************''
//   //****************TODO DELETE SHITTY SCREENSHOT CODE******************************''
//   //****************TODO DELETE SHITTY SCREENSHOT CODE******************************''
   SDL_RenderPresent(rend);
   SDL_DestroyTexture( ScTx);
}


V mainLoop(){
   static Uint64 last = 0;
   Uint64 now = SDL_GetPerformanceCounter();
   if(last == 0){ last = now; }

   F dt = (F)(now - last) / (F)SDL_GetPerformanceFrequency();
   last = now;

   events();
   tick(dt);
   render();

#if printfps
   fpsTimer += dt;
   fpsFrames += 1;
   if(fpsTimer >= 1.0f){
      printf("fps: %d\n", fpsFrames);
      fpsFrames = 0;
      fpsTimer -= 1.0f;
   }
#endif
}

V win(){won=1;ebtn=0;printf("WINNJER\n");};

V OPTnewgame(){reset();}
V warp(){
   rmFuel();
   alienLeave();
   alienShow=0;
   RwarpPowNoise=.7;
   GwarpPowNoise=2;
   BwarpPowNoise=1.5;
   alienCd=2+rand()%4;
   prog++;
   if(prog==progMAX){win();}
   printStats();
   warpEffect=warpEffectMax;
   warpDelay=1.0;
   skyTex=rand();
}


V OPTflyAway(){
   if(!CANACT){return;}
   if(warpDelay>0){ printf("warpDelay: %.3f", warpDelay);return;}
   alienTreshold *t = &alienTresholds[alienType];
   playShoot=0;
   if(alienShow && moodPass(t->fireFlee)){
      playShoot=playShootMax;
      takeDmg();
   }
   warpDelay=2.0;
   warpPreDelay=playShoot;

   alienRefueled=0;
}

V OPTtrade(){
   alienTreshold *t = &alienTresholds[alienType];
   I gotFuel = moodPass(t->rerefuel);
   I gotAmmo = moodPass(t->rearm);

   if(alienRefueled){
      playSoundError();
      return;
   }

   alienRefueled=1;

   if(gotFuel){ addFuel(); }
   if(gotAmmo){ ammo++;if(ammo>ammoMax){ammo--;} }

   if(!gotFuel && !gotAmmo){ playShoot=playShootMax; actCd=playShoot+.2; takeDmg(); alienLeave(); return; }
      

   RwarpPowNoise=.3;
   GwarpPowNoise=.6;
   BwarpPowNoise=.4;
   printStats();
}

V fight(){
   alienLeave();
   RwarpPowNoise=3;
   GwarpPowNoise=.4;
   BwarpPowNoise=8;
}

V OPTfight(){
   if(!alienShow){return;}
   fireEffect=fireEffectMax;
   actCd=fireEffectMax;
   ammo--;
   printStats();
}


V initBTN(){
   int btnH = 75;
   int btnW = 85;

   int signalBtnsX = 210;
   int signalBtnY = 370;
   int signalBtnXOff = 120;

   int diagBtnsX = 660;
   int diagBtnsY = 285;
   int diagBtnXOff = 70;
   int diagBtnYOff = 77;

   btns[1] = newBtn((Box){signalBtnsX + signalBtnXOff * 0, signalBtnY, btnW, btnH}, "res/btns/btnRN.png", "res/btns/btnRH.png", "res/btns/btnRP.png", setDrwCol1);
   btns[2] = newBtn((Box){signalBtnsX + signalBtnXOff * 1, signalBtnY, btnW, btnH}, "res/btns/btnGN.png", "res/btns/btnGH.png", "res/btns/btnGP.png", setDrwCol2);
   btns[3] = newBtn((Box){signalBtnsX + signalBtnXOff * 2, signalBtnY, btnW, btnH}, "res/btns/btnBN.png", "res/btns/btnBH.png", "res/btns/btnBP.png", setDrwCol3);
   btns[4] = newBtn((Box){signalBtnsX + signalBtnXOff * 3, signalBtnY, btnW, btnH}, "res/btns/btnPN.png", "res/btns/btnPH.png", "res/btns/btnPP.png", setDrwCol4);

   btns[0] = newBtn((Box){diagBtnsX + diagBtnXOff * 0, diagBtnsY + diagBtnYOff * 0, btnW, btnH}, "res/btns/btnN.png", "res/btns/btnH.png", "res/btns/btnP.png", OPTtrade);
   btns[5] = newBtn((Box){diagBtnsX + diagBtnXOff * 1, diagBtnsY + diagBtnYOff * 1, btnW, btnH}, "res/btns/btnN.png", "res/btns/btnH.png", "res/btns/btnP.png", OPTflyAway);
   btns[6] = newBtn((Box){diagBtnsX + diagBtnXOff * 2, diagBtnsY + diagBtnYOff * 2, btnW, btnH}, "res/btns/btnN.png", "res/btns/btnH.png", "res/btns/btnP.png", OPTfight);

   ebtns[0] = newBtn((Box){280,50,300,170}, "res/btns/ehome.png", "res/btns/ehomeh.png", "res/btns/ehomep.png",    OPTnewgame );
   ebtns[1] = newBtn((Box){280,50,300,170}, "res/btns/efuel.png", "res/btns/efuelh.png", "res/btns/efuelp.png",    OPTnewgame );
   ebtns[2] = newBtn((Box){280,50,300,170}, "res/btns/ebroke.png", "res/btns/ebrokeh.png", "res/btns/ebrokep.png", OPTnewgame );

}
I init(){
   running=1;
   reset();
   //display
   disp1 = newDisp((Box){245, 30, 360 , 240}, drwMainDisp);
   //signal scope
   disp2 = newDisp((Box){200, 290, signalLogW, 60}, drwSignalDisp);

   //init empty signal

   initBTN();

   //
   //txture txs[TX_COUNT] = {
   // [TXspace] = { "res/screen/space180x120.png", NULL },

   for (int i = 0; i < TX_COUNT; i++) {
      txs[i].tx = IMG_LoadTexture(rend, txs[i].path);
      if (!txs[i].tx) { printf("IMG_LoadTexture failed: %s\n", IMG_GetError()); return 0;}
   }

   ////////////////////
   /////animation frames

   for (int a = 0; a < AN_COUNT; a++) {
      animFrames[a] = malloc(sizeof(txture) * animsCnt[a]);
      for (int i = 0; i < animsCnt[a]; i++) {
         snprintf(animFrames[a][i].path, sizeof(animFrames[a][i].path), "%s%04d.png", anims[a].path, i + 1);

         animFrames[a][i].tx = IMG_LoadTexture(rend, animFrames[a][i].path);
         if (!animFrames[a][i].tx) { printf("IMG_LoadTexture failed: %s\n", IMG_GetError()); return 0; }
      }
   }

   ////////////////////////

   printf("init'd\n");

   SDL_Init(SDL_INIT_AUDIO);
   sinePlayerInit();

   return 1;
}
I main(){
   SDL_SetHint(SDL_HINT_EMSCRIPTEN_KEYBOARD_ELEMENT, "#canvas");
   SDL_Init(SDL_INIT_VIDEO);
   SDL_CreateWindowAndRenderer(W, H, 0, &wind, &rend);
   surf = SDL_CreateRGBSurfaceWithFormat(0, W, H, 32, SDL_PIXELFORMAT_ARGB8888);

   if(!init()){return 1;}


#ifdef __EMSCRIPTEN__
   emscripten_set_main_loop(mainLoop, 0, 1);
#else
   const F target = 1.0f / 60.0f;

   while(running){
      Uint64 frameStart = SDL_GetPerformanceCounter();

      mainLoop();

      Uint64 frameEnd = SDL_GetPerformanceCounter();
      F frameTime = (F)(frameEnd - frameStart) / (F)SDL_GetPerformanceFrequency();

      if(frameTime < target){
         SDL_Delay((Uint32)((target - frameTime) * 1000.0f));
      }

   }
#endif 
return 0;

}
//eof main.c============================================
